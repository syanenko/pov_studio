# Studio render
# time ../../../povray/bin/povray -i./studio.pov -omodel ../../../povray/etc/povray/3.8/povray_800x600.ini
time ../../../povray/bin/povray -i./studio.pov -omodel ../../../povray/etc/povray/3.8/povray_1920x1080.ini

